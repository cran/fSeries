Gabriele Fiorentini, Giorgio Calzolari, and Lorenzo Panattoni, "Analytic 
Derivatives and the Computation of GARCH Estimates", Journal of Applied 
Econometrics, Vol. 11, No. 4, 1996, pp. 399-417.

Authors' address:

c/o Universita' di Firenze
    Dept. of Statistics
    Viale Morgagni 59
    50134 Firenze (Italy)

All files are zipped in the file fcp-progs.zip. These are DOS files.

The full data set is composed by:

1 MAIN program in Fortran (MAIN.FOR)

2 subroutines in Fortran,
  one to apply the mixed gradient method and
  evaluate the convergence speed (VSGARCMX.FOR)
  and one to compute different estimates of the covariance
  matrix (VSGARCOV.FOR).

2 .BAT procedures, which are incomplete (they must be completed
  with the appropriate LINK and RUN commands, which depend on the
  particular Fortran installed at the user's location).
  One is to apply the mixed gradient method and
  evaluate the convergence speed (GARCHMIX.BAT)
  and one to compute different estimates of the covariance
  matrix (GARCHCOV.BAT).

3 models, each composed by a two files
  (a small Fortran code, containing
  the structure of the mean equation, and a data file:
  MODEL1.FOR, MODEL1.DAT
  MODEL2.FOR, MODEL2.DAT
  MODEL3.FOR, MODEL3.DAT)
1 file (VSINIT.RND) to initialize random numbers

Be sure that that the data filenames are in CAPITAL letters, or change the
OPEN statements. This may be a problem for Unix systems. 

****************************************************************
DOS Installation
****************************************************************
Compile all the Fortran codes (6 programs).
           (In principle, any Fortran 77 compiler should be
           appropriate. We have verified that the programs run
           with Microway NDP-386 fortran on PC 486,
           with Microway fortran for Pentium,
           with Lahey fortran 77 on PC 486,
           with IBM fortran under Aix-Unix on Risc 6000).
Complete the two .BAT procedures with the appropriate LINK and RUN
commands.
Run one of the three models (without changes, the first time)
by issuing the following command:
GARCHMIX MODEL1
Apart from the information that appears on the screen,
at the end of the execution the summary statistics are contained
in the file
FORT8.OUT
Print such a file (an ASCII file).

Enter now the following command
GARCHCOV MODEL1
At the end of the execution, 3 files are produced:
FORT8.OUT  containing summary statistics, to be printed
FORT35.DAT containing for each Monte Carlo replication
           the values of the log-likelihood (till convergence),
           the values of different Wald statistics, using
           the different covariance matrices, the null hypothesis
           being always: parameters equal to their "true" values
           (i.e.values read from the .DAT file and used for simulations).
           Each group of Wald statistics is first computed for all
           parameters, then only for the coefficients of the
           mean equation, then only for the variance parameters
           (alpha and beta).
           All the above statistics are computed using the full
           outer products matrix (when it is used).
           The entire group of Wald statistics is re-computed
           using the block-diagonal matrix of outer products.
           An integer number at the beginning of each line
           recalls how many parameters are involved in the Wald
           statistic (and therefore the number of degrees of freedom).
FORT67.DAT containing for each Monte Carlo replication
           the values of all parameters upon convergence.
The two files
FORT35.DAT and FORT67.DAT can be processed by the user
with his own programs, to produce other summary statistics
or pictures.

****************************************************************
To perform different simulations
****************************************************************
The .DAT corresponding to the chosen model must be modified
(e.g. MODEL1.DAT)
The format of the .DAT file is not-flexible
and must be treated with great care.

Line 1  and 2 contain comments, anything can be written
        in these two lines, provided that these 2 lines exist!
Line 3: this line contains 11 integer numbers, that must be
        written with format (11I5), that is 5 digits each, right
        adjusted.
Number   1: number of Monte Carlo replications. If =0, it
            means that the estimation is on
            historical data (read from the same file).
Number   2: must be equal to the previous (not used by these programs)
Numbers  3  and 4: must be =1
Number   5: is the number of exogenous variables in the mean equation
            (coded as X(1,I), X(2,I) etc. in the corresponding
            file .FOR, e.g. MODEL1.FOR)
Number   6: is the number of coefficients in the mean equation
            (coded as A(1), A(2) etc. in the corresponding
            file .FOR, e.g. MODEL1.FOR)
Numbers  7  and 8: initial and final period of the hystorical time
            series
            in the file (dependent and exogenous variables).
            If the different series have different length,
            the first number must be the smallest among the
            initial periods, while the second must be the largest
            among the final periods of all the series.
Numbers  9  and 10: initial and final period of the desired
            simulation period.
            If hystorical data are to be used (first two
            numbers in this third line are both zero),
            be sure to have
            enough data for the desired simulation.
Number  11: must be =0 for static simulation (one-step ahead),
            must be =1 for dynamic simulation
Line 4: two integer numbers (format 2I5) indicating
        initial and final period of the time series which follows.
From line 5: The hystorical values of the dependent variable Y(1),
             four values in each line, all values must be
             real (with decimal point), 15 characters each
             (recommended format is 4G15.6)
Next line:   two integer numbers (format 2I5) indicating
             initial and final period of the time series which follows
             (that is the first exogenous variable).
From following line: The hystorical values of the first
                     exogenous variable (if any),
                     four values in each line, all values must be
                     real (with decimal point), 15 characters each
                     (recommended format is 4G15.6)

The same is repeated for all the exogenous variables:
one heading line with initial and final period, then the time series
with the same format as above.

Next line: two integer numbers (format 2I5) indicating
           initial and final period of the residuals
From following line: residuals,
                     five values in each line, all values must be
                     real (with decimal point), 15 characters each
                     (recommended format is 5G15.6)
Next line: one integer number (format I5) indicating
           the number of coefficients in the mean equation.
From following line: coefficients of the mean equation,
                     five values in each line, all values must be
                     real (with decimal point), 15 characters each
                     (recommended format is 5G15.6)
From following line: covariance matrix of the
                     coefficients of the mean equation,
                     (only the lower triangle,
                     one number in the first line, two in the next
                     three in the next, etc,
                     one more line if six or more),
                     all values must be
                     real (with decimal point), 15 characters each
                     (recommended format is 5G15.6)
Next line: one integer number =degrees of freedom.
           Must be =0 if random error terms
           must be normal.
           Must be =2, or =3, etc. if Student's t is to be used.
           This option is valid only for VSGARCOV.
           For VSGARCMX a number must be written here,
           but is not used (only normal errors are generated).
Next line: a real number of 15 characters (recommended format G15.6)
           which is the value of ALPHA0
Next line: one integer number (format I5)
           indicating the number of alpha parameters
           (=1 for Arch(1) or Garch(1,1) or Garch(1,2), etc.
            =2 for Arch(2) or Garch(2,1) or Garch(2,2), etc.)
Next line: all alpha parameters with format 5G15.6.
Next line: one integer number (format I5)
           indicating the number of beta parameters
           (=0 for Arch(1) or Arch(2),
            =1 for Garch(1,1) or Garch(2,1), etc.)
Next line: all beta parameters with format 5G15.6.

****************************************************************
Modifying Fortran subroutines VSGARCMX and VSGARCOV
****************************************************************

If an error message is printed concerning insufficient dimensions, these
subroutines must be edited and dimensions enlarged. The dimensions allowed
are listed in the first lines and must be changed everywhere. The use of
an editor's "change global" is recommended, including, in the numbers to
be changed, the leading zeroes of the dimension statements, that prevent
from accidental modification of other statements that should not be
changed. For example, the maximum length of time series, in both programs
VAGARCMX and VSGARCOV, is now 3009, and it is written 003009. To enlarge
it up to 8500, edit one of the two programs and enter an edit command
like: CHANGE /003009/008500/ * * Then save and re-compile. 

If an error message is related to insufficient dimensions in the main
program, it will be marked "MAIN", and in this case the MAIN.FOR must be
edited and dimensions changed. The dimension to be changed is clearly
marked at the beginning of the program. 

It is possible to activate different options by modifying the fortran
subroutines. For example, it is possible to generate random exogenous
variables, or alternatively to use the historical values of exogenous to
generate random values of the dependent variable. The choice among
alternative options of this kind can be done by locating, inside the
fortran subroutines, the keyword 'ACTIVATE', and the activating or not the
statement which immediately follows (it is marked clearly in the files).
Then save and re-compile the program. 

